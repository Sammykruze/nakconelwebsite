exports.handler = async function(event, context) {
  const headers = {'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type','Access-Control-Allow-Methods':'POST, OPTIONS','Content-Type':'application/json'};
  if (event.httpMethod === 'OPTIONS') return {statusCode:200,headers,body:''};
  if (event.httpMethod !== 'POST') return {statusCode:405,headers,body:JSON.stringify({error:'Method not allowed'})};
  try {
    const {prompt,imageData,imageType} = JSON.parse(event.body);
    const POLLINATIONS_KEY = process.env.POLLINATIONS_API_KEY;
    const GROQ_KEY = process.env.GROQ_API_KEY || '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';
    if (!prompt) return {statusCode:400,headers,body:JSON.stringify({error:'Missing prompt'})};
    if (!POLLINATIONS_KEY) return {statusCode:200,headers,body:JSON.stringify({error:'Image generation is not set up yet.'})};

    // Step 1: expand the user's short request into a rich, detailed prompt (this is what makes ChatGPT-style
    // image generation look noticeably better than feeding the raw request straight to the image model)
    let finalPrompt = prompt;
    if (GROQ_KEY) {
      try {
        const enhanceR = await fetch('https://api.groq.com/openai/v1/chat/completions', {
          method: 'POST',
          headers: {'Content-Type':'application/json','Authorization':`Bearer ${GROQ_KEY}`},
          body: JSON.stringify({
            model: 'llama-3.3-70b-versatile',
            max_tokens: 120,
            temperature: 0.8,
            messages: [
              {role:'system', content: 'You write vivid, detailed text-to-image prompts for an AI image generator, in 2-3 sentences maximum. Given a short request, describe: subject, composition, lighting, color palette, style, and mood. If it is a logo request, describe a clean, professional, print-ready vector-style logo concept. Output ONLY the prompt text, nothing else — no preamble, no quotes, no labels. Keep it under 60 words.'},
              {role:'user', content: prompt}
            ]
          })
        });
        const enhanceD = await enhanceR.json();
        const expanded = enhanceD.choices?.[0]?.message?.content?.trim();
        if (expanded) finalPrompt = expanded.slice(0, 600);
      } catch { /* fall back silently to the raw prompt */ }
    }

    // Note: Pollinations' image-editing models need a hosted reference image URL, which we don't have for
    // a freshly uploaded photo — so for now every request is generated from the (enhanced) text description.
    // Using the POST endpoint (OpenAI-compatible) instead of the GET URL form avoids URL-length/encoding
    // issues that can trip up the backend on longer, richly-detailed prompts.
    const r = await fetch('https://gen.pollinations.ai/v1/images/generations', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${POLLINATIONS_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'flux',
        prompt: finalPrompt,
        n: 1,
        size: '1024x1024',
        response_format: 'b64_json'
      })
    });

    if (!r.ok) {
      const errText = await r.text().catch(()=> '');
      return {statusCode:200,headers,body:JSON.stringify({error:`Image generation failed (${r.status}). ${errText.slice(0,200)}`})};
    }

    const data = await r.json();
    const item = data?.data?.[0];
    if (!item) return {statusCode:200,headers,body:JSON.stringify({error:'No image returned — please try again.'})};

    let imageOut;
    if (item.b64_json) {
      imageOut = `data:image/jpeg;base64,${item.b64_json}`;
    } else if (item.url) {
      const imgR = await fetch(item.url);
      const buffer = await imgR.arrayBuffer();
      const base64 = Buffer.from(buffer).toString('base64');
      const contentType = imgR.headers.get('content-type') || 'image/jpeg';
      imageOut = `data:${contentType};base64,${base64}`;
    } else {
      return {statusCode:200,headers,body:JSON.stringify({error:'Unexpected response from image service.'})};
    }

    return {statusCode:200,headers,body:JSON.stringify({image:imageOut,promptUsed:finalPrompt})};
  } catch(err) {
    return {statusCode:500,headers,body:JSON.stringify({error:'Connection error. Please try again.'})};
  }
};
