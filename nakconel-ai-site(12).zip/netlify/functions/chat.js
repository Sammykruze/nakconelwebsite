exports.handler = async function(event, context) {
  const headers = {'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type','Access-Control-Allow-Methods':'POST, OPTIONS','Content-Type':'application/json'};
  if (event.httpMethod === 'OPTIONS') return {statusCode:200,headers,body:''};
  if (event.httpMethod !== 'POST') return {statusCode:405,headers,body:JSON.stringify({reply:'Method not allowed'})};
  try {
    const {messages,userName,imageData,imageType,hasImage,memoryContext} = JSON.parse(event.body);
    const GROQ_KEY = process.env.GROQ_API_KEY || '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';
    const GEMINI_KEY = process.env.GEMINI_API_KEY;
    let memoryNote = '';
    if (Array.isArray(memoryContext) && memoryContext.length) {
      const summary = memoryContext.map(m => `${m.role==='user'?'User':'You'}: ${m.content}`).join('\n');
      memoryNote = `\n\nContext remembered from earlier conversations with this user (use it naturally, don't explicitly mention "memory" unless asked):\n${summary}`;
    }
    const sys = `You are Nakconel AI, the brand intelligence assistant for Nakconel — a brand management and AI strategy company. You speak with clarity, confidence, and cultural respect: strategic not vague, premium not distant, intelligent not complicated, global not generic, helpful not hype-driven.

Your job is to help people build stronger brands. You specialize in Nakconel's five pillars and should steer every conversation toward them where possible:
1. Brand Strategy — positioning, market clarity, audience intelligence, brand architecture, naming, messaging, growth planning.
2. Content & Design — visual identity direction, campaign concepts, social content systems, editorial/storytelling, design briefs, graphic and logo concepts.
3. IT & Technology — websites, client portals, workflow tools, automation, digital transformation guidance.
4. AI Enablement — AI adoption roadmaps, prompt systems, AI content workflows, brand intelligence dashboards, automation for teams.
5. Cultural Intelligence — market-aware branding guidance for Africa, the United States, Australia, and Gulf countries (Kuwait, Dubai, Qatar, and surrounding regions).

When someone asks you to generate creative assets (images, designs, jingles, copy), treat it as brand work: ask what the brand stands for if it isn't clear, then produce something usable — taglines, brand voice samples, content calendars, campaign concepts, naming options. IMPORTANT: never write raw HTML or CSS code as a design mockup or visual concept — this app has a dedicated image generator for that, and users should just describe what they want to see rather than receiving code. If someone wants an actual visual (logo, image, design, mockup on a product), tell them briefly to describe it and it will be generated as a real image — do not attempt to represent it in text or code yourself. Only use code blocks for genuine programming/technical help, not for design mockups. Always use proper markdown code blocks with language tags like \`\`\`python when sharing real code.

If someone asks about something entirely unrelated to brands, business, marketing, design, or AI strategy, answer briefly and helpfully, then gently steer back: offer how Nakconel AI could help with their brand instead. Avoid empty buzzwords, overpromising AI results, copying cultural symbols without permission, and generic motivational language. Answer directly first, be concise, and adapt tone to the user. User's name: ${userName||'there'}.${memoryNote}`;

    if (hasImage && imageData && GEMINI_KEY) {
      const lastMsg = messages[messages.length-1]?.content || 'What is in this image?';
      const contents = [];
      for (let i=0;i<messages.length-1;i++) if(messages[i].content) contents.push({role:messages[i].role==='assistant'?'model':'user',parts:[{text:messages[i].content}]});
      contents.push({role:'user',parts:[{inline_data:{mime_type:imageType||'image/jpeg',data:imageData}},{text:lastMsg}]});
      for (const model of ['gemini-1.5-flash-8b','gemini-1.5-flash','gemini-1.5-pro']) {
        try {
          const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${GEMINI_KEY}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({system_instruction:{parts:[{text:sys}]},contents,generationConfig:{maxOutputTokens:1000,temperature:0.7}})});
          const d = await r.json();
          if (d.error?.code===429||d.error?.status==='RESOURCE_EXHAUSTED') continue;
          if (d.error) throw new Error(d.error.message);
          const reply = d.candidates?.[0]?.content?.parts?.[0]?.text;
          if (reply) return {statusCode:200,headers,body:JSON.stringify({reply,model:'gemini-vision'})};
        } catch {continue;}
      }
      return {statusCode:200,headers,body:JSON.stringify({reply:"⚠️ Image analysis quota reached. Resets at midnight!",model:'fallback'})};
    }

    const r = await fetch('https://api.groq.com/openai/v1/chat/completions',{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${GROQ_KEY}`},body:JSON.stringify({model:'llama-3.3-70b-versatile',max_tokens:1024,messages:[{role:'system',content:sys},...messages]})});
    const d = await r.json();
    const reply = d.choices?.[0]?.message?.content || "I'm having trouble responding. Please try again.";
    return {statusCode:200,headers,body:JSON.stringify({reply,model:'groq'})};
  } catch(err) {
    return {statusCode:500,headers,body:JSON.stringify({reply:"Connection error. Please try again."})};
  }
};
